import os
import time
import pyautogui
import pytesseract
from PIL import Image
import numpy as np
import re
from datetime import datetime, timedelta

# 設定 Tesseract OCR 路徑
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# 設定資料夾路徑
screenshot_folder = os.path.join(os.path.dirname(__file__), "screenshot")
os.makedirs(screenshot_folder, exist_ok=True)

# 設定上次啟動時間檔案路徑
last_run_file = os.path.join(os.path.dirname(__file__), "last_run.txt")

# 顏色設定
complete_answer_color = (39, 206, 136)  # 完成答題顏色 RGB
bookwork_code_background_color = (46, 60, 113)  # Bookwork code 背景顏色 RGB
bookwork_check_text = "Bookwork check"  # Bookwork check 文字
bookwork_check_code_color = (44, 206, 136)  # 假設顏色設定，根據實際顏色調整
correct_text = "Correct!"  # 完成答題後的文字檢測

# 函數: 記錄當前時間為上次啟動時間
def record_last_run_time():
    with open(last_run_file, 'w') as f:
        f.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

# 函數: 讀取上次啟動時間
def get_last_run_time():
    if os.path.exists(last_run_file):
        with open(last_run_file, 'r') as f:
            last_run_str = f.read()
            return datetime.strptime(last_run_str, "%Y-%m-%d %H:%M:%S")
    return None

# 函數: 截圖整個螢幕
def take_screenshot():
    screenshot = pyautogui.screenshot()
    return screenshot

# 函數: 偵測顏色是否在螢幕上
def detect_color(color, screenshot):
    screenshot_np = np.array(screenshot)
    return np.any(np.all(screenshot_np == color, axis=-1))

# 函數: 偵測螢幕中是否包含指定文字
def detect_text_in_screen(text, screenshot):
    text_found = pytesseract.image_to_string(screenshot)
    if text in text_found:
        return True
    return False

# 函數: 偵測顏色範圍內的 Bookwork code
def detect_bookwork_code(screenshot):
    screenshot_np = np.array(screenshot)
    for x in range(screenshot_np.shape[1]):
        for y in range(screenshot_np.shape[0]):
            # 偵測到背景顏色，表示可能是 Bookwork code
            if tuple(screenshot_np[y, x]) == bookwork_code_background_color:
                # 假設從這個位置開始提取文字
                region = screenshot.crop((x-100, y-20, x+150, y+20))  # 根據需要調整範圍
                text = extract_text_from_image(region)
                bookwork_code_match = re.search(r"Bookwork\s*(\S+)", text)
                if bookwork_code_match:
                    return bookwork_code_match.group(1)
    return None

# 函數: 使用 OCR 讀取圖片中的文字
def extract_text_from_image(image):
    text = pytesseract.image_to_string(image)
    return text

# 函數: 偵測是否有完成答題顏色並抓取 Bookwork Code
def detect_complete_answer_and_code():
    screenshot = take_screenshot()
    if detect_color(complete_answer_color, screenshot):
        # 找到完成答題顏色後，檢查是否顯示 "Correct!"
        if detect_text_in_screen(correct_text, screenshot):
            # 如果有 "Correct!" 文字，則檢查 Bookwork code:
            text = extract_text_from_image(screenshot)
            bookwork_code_match = re.search(r"Bookwork code:\s*(\S+)", text)
            if bookwork_code_match:
                bookwork_code = bookwork_code_match.group(1)
                screenshot_name = f"{bookwork_code}.png"
                screenshot.save(os.path.join(screenshot_folder, screenshot_name))
                print(f"截圖已保存為 {screenshot_name}")
            else:
                print("未找到 Bookwork code")
        else:
            print("未找到 'Correct!' 文字")
    else:
        print("未找到完成答題顏色")

# 函數: 偵測是否有 Bookwork check 並打開對應的截圖
def detect_bookwork_check_and_open():
    screenshot = take_screenshot()
    text = extract_text_from_image(screenshot)
    if bookwork_check_text in text:
        # 嘗試偵測 Bookwork code
        bookwork_code = detect_bookwork_code(screenshot)
        if bookwork_code:
            screenshot_path = os.path.join(screenshot_folder, f"{bookwork_code}.png")
            if os.path.exists(screenshot_path):
                print("loading screenshot...")  # 顯示 loading 訊息
                try:
                    screenshot_image = Image.open(screenshot_path)
                    screenshot_image.show()  # 顯示截圖
                    print(f"打開截圖: {screenshot_path}")
                except Exception as e:
                    print(f"無法開啟圖片: {e}")
            else:
                print(f"找不到對應的截圖：{screenshot_path}")
        else:
            print("未找到 Bookwork code")
    else:
        print("未找到 Bookwork check")

# 函數: 刪除資料夾內的所有圖片
def delete_previous_screenshots():
    # 讀取上次啟動時間
    last_run_time = get_last_run_time()
    if last_run_time:
        time_diff = datetime.now() - last_run_time
        # 如果距離上次啟動超過 1 小時，則刪除圖片
        if time_diff > timedelta(hours=1):
            for file_name in os.listdir(screenshot_folder):
                file_path = os.path.join(screenshot_folder, file_name)
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    print(f"已刪除圖片：{file_name}")
        else:
            print("距離上次啟動未超過一小時，不會刪除圖片。")
    else:
        print("無法讀取上次啟動時間，跳過圖片刪除。")

# 每次啟動時刪除上次保存的圖片（如果超過一小時）
delete_previous_screenshots()

# 記錄當前啟動時間
record_last_run_time()

# 主程式循環
def main():
    while True:
        detect_complete_answer_and_code()  # 偵測完成答題顏色及保存截圖
        detect_bookwork_check_and_open()  # 偵測 Bookwork check 並打開截圖
        time.sleep(1)  # 每 1 秒鐘檢查一次

# 開始執行程式
if __name__ == "__main__":
    main()
