import os
import sys
import subprocess
import time
import pyautogui
import pytesseract
from PIL import Image
import numpy as np
import re

# 函數: 自動檢查並安裝所需的組件
def install_missing_package(package_name):
    try:
        __import__(package_name)
    except ImportError:
        print(f"缺少組件 {package_name}，正在自動安裝...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        print(f"已安裝組件 {package_name}")

# 安裝所需組件
required_packages = ["pytesseract", "pillow", "numpy", "pyautogui"]
for package in required_packages:
    install_missing_package(package)

# 函數: 檢查 Tesseract OCR 是否已安裝
def check_tesseract():
    tesseract_path = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    if not os.path.exists(tesseract_path):
        print("Tesseract OCR 未安裝！請先安裝 Tesseract OCR 後再運行程式。")
        sys.exit("程式終止。請下載並安裝 Tesseract OCR。")
    pytesseract.pytesseract.tesseract_cmd = tesseract_path
    print("已檢測到 Tesseract OCR。")

# 檢查 Tesseract OCR
check_tesseract()

# 設定資料夾路徑
screenshot_folder = os.path.join(os.path.dirname(__file__), "screenshot")
os.makedirs(screenshot_folder, exist_ok=True)

# 顏色設定
complete_answer_color = (39, 206, 136)  # 完成答題顏色 RGB
bookwork_code_background_color = (46, 60, 113)  # Bookwork code 背景顏色 RGB
correct_text = "Correct!"  # 偵測 "Correct!" 文本

# 函數: 截圖整個螢幕
def take_screenshot():
    return pyautogui.screenshot()

# 函數: 偵測文字是否出現在螢幕上
def detect_text_in_screen(text, screenshot):
    ocr_result = pytesseract.image_to_string(screenshot)
    return text in ocr_result

# 函數: 偵測顏色是否在螢幕上
def detect_color(color, screenshot):
    screenshot_np = np.array(screenshot)
    for x in range(screenshot_np.shape[1]):
        for y in range(screenshot_np.shape[0]):
            if tuple(screenshot_np[y, x]) == color:
                return True
    return False

# 函數: 偵測是否有完成答題顏色或文字
def detect_complete_answer_and_code():
    screenshot = take_screenshot()
    # 偵測完成顏色或 "Correct!" 文本
    if detect_color(complete_answer_color, screenshot) or detect_text_in_screen(correct_text, screenshot):
        print("檢測到完成答題條件！")
        # 偵測 Bookwork code 並保存截圖
        text = pytesseract.image_to_string(screenshot)
        bookwork_code_match = re.search(r"Bookwork code:\s*(\S+)", text)
        if bookwork_code_match:
            bookwork_code = bookwork_code_match.group(1)
            screenshot_name = f"{bookwork_code}.png"
            screenshot.save(os.path.join(screenshot_folder, screenshot_name))
            print(f"截圖已保存為 {screenshot_name}")
        else:
            print("未找到 Bookwork code")
    else:
        print("未找到完成答題條件")

# 函數: 刪除資料夾內的所有圖片 (如果距離上次啟動超過 1 小時)
def delete_old_screenshots():
    current_time = time.time()
    last_run_file = os.path.join(screenshot_folder, "last_run.txt")
    if os.path.exists(last_run_file):
        with open(last_run_file, "r") as f:
            last_run_time = float(f.read().strip())
        if current_time - last_run_time > 3600:  # 超過 1 小時
            for file_name in os.listdir(screenshot_folder):
                file_path = os.path.join(screenshot_folder, file_name)
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    print(f"已刪除圖片：{file_name}")
    # 更新最後運行時間
    with open(last_run_file, "w") as f:
        f.write(str(current_time))

# 初始化：檢查並刪除舊截圖
delete_old_screenshots()

# 主程式循環
def main():
    while True:
        detect_complete_answer_and_code()  # 偵測完成答題條件並保存截圖
        time.sleep(1)  # 每 1 秒檢查一次

# 開始執行程式
if __name__ == "__main__":
    main()
